package com.example.srcwh

const val LOGIN_URL = "https://srcwh.xyz/login"